import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

/**
 * The three decision algorithms for regular languages of
 * Session 23, each one transcribing its slide.
 *
 * Run from this folder with:  java Main.java
 * or on your own DFAs (e.g. exported from the DFA visualizer):
 *   java Main.java member <dfa.json> <word>...
 *   java Main.java empty  <dfa.json>
 *   java Main.java equiv  <dfa1.json> <dfa2.json>
 */
public class Main {

    /**
     * DECISION PROBLEM 1: Membership testing.
     *
     * @return true if word ∈ L(dfa), false otherwise.
     */
    public static boolean membershipTest(DFA dfa, String word) {
        String state = dfa.getStartState();          // Start at the initial state.
        for (char symbol : word.toCharArray()) {     // For each letter of w,
            if (!dfa.getAlphabet().contains(symbol)) {
                return false;                        // (w is not even a word over the alphabet)
            }
            state = dfa.next(state, symbol);         // follow the corresponding transition.
        }
        return dfa.getFinalStates().contains(state); // w ∈ L iff we end in a final state.
    }

    /**
     * DECISION PROBLEM 2: Emptiness testing, by BFS from the start state.
     *
     * @return true if L(dfa) = ∅, false otherwise.
     */
    public static boolean emptinessTest(DFA dfa) {
        Set<String> visited = new HashSet<>();
        Queue<String> queue = new LinkedList<>();

        // Initially, mark the start state as visited and add it to a queue.
        visited.add(dfa.getStartState());
        queue.add(dfa.getStartState());

        while (!queue.isEmpty()) {
            String state = queue.poll();                  // Dequeue a state s.
            if (dfa.getFinalStates().contains(state)) {
                return false;                             // s is final: the language is not empty.
            }
            for (char symbol : dfa.getAlphabet()) {       // Otherwise, enqueue all unvisited
                String next = dfa.next(state, symbol);    // states reachable from s
                if (!visited.contains(next)) {            // and mark them as visited.
                    visited.add(next);
                    queue.add(next);
                }
            }
        }
        return true;                                      // No final state reached: the language is empty.
    }

    /**
     * DECISION PROBLEM 3: Equivalence testing.
     * L1 = L2 iff L1 ∩ ¬L2 = ∅ and L2 ∩ ¬L1 = ∅.
     *
     * @return true if L(dfa1) = L(dfa2), false otherwise.
     */
    public static boolean equivalenceTest(DFA dfa1, DFA dfa2) {
        DFA onlyIn1 = dfa1.product(dfa2.complement());    // recognizes L1 ∩ ¬L2
        DFA onlyIn2 = dfa2.product(dfa1.complement());    // recognizes L2 ∩ ¬L1
        return emptinessTest(onlyIn1) && emptinessTest(onlyIn2);
    }

    private static final String USAGE = String.join("\n",
        "Usage:",
        "  java Main.java                                  run the demo",
        "  java Main.java member <dfa.json> <word>...      is each word in L?",
        "  java Main.java empty  <dfa.json>                is L empty?",
        "  java Main.java equiv  <dfa1.json> <dfa2.json>   is L1 = L2?");

    public static void main(String[] args) {
        String command = args.length == 0 ? "demo" : args[0];
        try {
            if (command.equals("demo")) {
                demo();
            } else if (command.equals("member") && args.length >= 3) {
                DFA dfa = DFA.fromJSON(args[1]);
                for (int i = 2; i < args.length; i++) {
                    System.out.println("\"" + args[i] + "\": " + membershipTest(dfa, args[i]));
                }
            } else if (command.equals("empty") && args.length == 2) {
                System.out.println(emptinessTest(DFA.fromJSON(args[1])));
            } else if (command.equals("equiv") && args.length == 3) {
                System.out.println(equivalenceTest(DFA.fromJSON(args[1]), DFA.fromJSON(args[2])));
            } else {
                System.err.println(USAGE);
                System.exit(1);
            }
        } catch (IOException e) {
            System.err.println("Cannot read " + e.getMessage());
            System.exit(1);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }

    private static void demo() throws IOException {
        DFA endsAb     = DFA.fromJSON("examples/ends_ab.json");     // words ending in ab (3 states)
        DFA endsAbBig  = DFA.fromJSON("examples/ends_ab_big.json"); // same language (4 states: last two letters)
        DFA containsAb = DFA.fromJSON("examples/contains_ab.json"); // words containing ab
        DFA empty      = DFA.fromJSON("examples/empty.json");       // its final state is unreachable

        System.out.println("--- Membership: is w in L(ends_ab)? ---");
        for (String word : new String[] {"", "ab", "abab", "aba", "bbab"}) {
            System.out.println("  \"" + word + "\": " + membershipTest(endsAb, word));
        }

        System.out.println("--- Emptiness: is L empty? ---");
        System.out.println("  ends_ab: " + emptinessTest(endsAb));
        System.out.println("  empty:   " + emptinessTest(empty));

        System.out.println("--- Equivalence: are the languages equal? ---");
        System.out.println("  ends_ab, ends_ab_big: " + equivalenceTest(endsAb, endsAbBig));
        System.out.println("  ends_ab, contains_ab: " + equivalenceTest(endsAb, containsAb));
    }
}
