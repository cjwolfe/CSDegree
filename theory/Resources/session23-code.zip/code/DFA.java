import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Represents a complete Deterministic Finite Automaton (DFA):
 * every state has a transition for every letter of the alphabet.
 */
public class DFA {

    private Set<String> states;
    private Set<Character> alphabet;
    private Map<String, Map<Character, String>> transitions;
    private String startState;
    private Set<String> finalStates;

    /**
     * Constructs a new DFA.
     *
     * @param states The set of states in the DFA.
     * @param alphabet The alphabet of the DFA.
     * @param transitions The transition function of the DFA.
     * @param startState The start state of the DFA.
     * @param finalStates The set of final states of the DFA.
     * @throws IllegalArgumentException If the DFA is not complete.
     */
    public DFA(Set<String> states, Set<Character> alphabet, Map<String, Map<Character, String>> transitions, String startState, Set<String> finalStates) {
        // complement() is only correct on complete DFAs, so we refuse incomplete ones
        if (!states.contains(startState)) {
            throw new IllegalArgumentException("Start state " + startState + " is not a state");
        }
        for (String state : states) {
            for (char symbol : alphabet) {
                Map<Character, String> stateTransitions = transitions.get(state);
                if (stateTransitions == null || !states.contains(stateTransitions.get(symbol))) {
                    throw new IllegalArgumentException("Missing transition from state " + state + " on symbol " + symbol);
                }
            }
        }
        this.states = states;
        this.alphabet = alphabet;
        this.transitions = transitions;
        this.startState = startState;
        this.finalStates = finalStates;
    }

    /**
     * Creates a DFA from a JSON file exported by the DFA visualizer.
     *
     * @param filename The path to the JSON file.
     * @return A new DFA instance.
     * @throws IOException If the file cannot be read.
     */
    public static DFA fromJSON(String filename) throws IOException {
        JSONParser parser = new JSONParser(Files.readString(Path.of(filename)));
        JSONParser.JSONObject json = parser.parseObject();

        // Parse alphabet
        JSONParser.JSONArray alphabetArray = json.getJSONArray("alphabet");
        Set<Character> alphabet = new HashSet<>();
        for (int i = 0; i < alphabetArray.length(); i++) {
            String symbol = alphabetArray.getString(i);
            if (symbol.length() != 1) {
                throw new IllegalArgumentException("Alphabet symbols must be single characters");
            }
            alphabet.add(symbol.charAt(0));
        }

        // Parse states
        JSONParser.JSONArray statesArray = json.getJSONArray("states");
        Set<String> states = new HashSet<>();
        for (int i = 0; i < statesArray.length(); i++) {
            states.add(statesArray.getString(i));
        }

        // Parse start state
        String startState = json.getString("initialState");

        // Parse final states
        JSONParser.JSONArray finalStatesArray = json.getJSONArray("finalStates");
        Set<String> finalStates = new HashSet<>();
        for (int i = 0; i < finalStatesArray.length(); i++) {
            finalStates.add(finalStatesArray.getString(i));
        }

        // Parse transitions
        JSONParser.JSONObject transitionsObj = json.getJSONObject("transitions");
        Map<String, Map<Character, String>> transitions = new HashMap<>();
        for (String state : transitionsObj.keySet()) {
            JSONParser.JSONObject stateTransitions = transitionsObj.getJSONObject(state);
            Map<Character, String> trans = new HashMap<>();
            for (String symbol : stateTransitions.keySet()) {
                if (symbol.length() != 1) {
                    throw new IllegalArgumentException("Transition symbols must be single characters");
                }
                trans.put(symbol.charAt(0), stateTransitions.getString(symbol));
            }
            transitions.put(state, trans);
        }

        return new DFA(states, alphabet, transitions, startState, finalStates);
    }

    // Getters
    public Set<Character> getAlphabet() {
        return alphabet;
    }

    public String getStartState() {
        return startState;
    }

    public Set<String> getFinalStates() {
        return finalStates;
    }

    /**
     * The transition function δ.
     *
     * @return The state reached from state by reading symbol.
     */
    public String next(String state, char symbol) {
        return transitions.get(state).get(symbol);
    }

    /**
     * Complementation algorithm: swap final and non-final states.
     *
     * @return A new DFA recognizing the complement of the language of this DFA.
     */
    public DFA complement() {
        Set<String> newFinalStates = new HashSet<>(states);
        newFinalStates.removeAll(finalStates);
        return new DFA(states, alphabet, transitions, startState, newFinalStates);
    }

    /**
     * Product algorithm: states are pairs (p,q), and (p,q) is final
     * iff both p and q are final.
     *
     * @param other A DFA over the same alphabet.
     * @return A new DFA recognizing the intersection of both languages.
     */
    public DFA product(DFA other) {
        if (!alphabet.equals(other.alphabet)) {
            throw new IllegalArgumentException("Both DFAs must have the same alphabet");
        }

        Set<String> newStates = new HashSet<>();
        Map<String, Map<Character, String>> newTransitions = new HashMap<>();
        Set<String> newFinalStates = new HashSet<>();

        for (String p : states) {
            for (String q : other.states) {
                String pq = pair(p, q);
                newStates.add(pq);

                // δ((p,q), a) = (δ1(p,a), δ2(q,a))
                Map<Character, String> trans = new HashMap<>();
                for (char symbol : alphabet) {
                    trans.put(symbol, pair(next(p, symbol), other.next(q, symbol)));
                }
                newTransitions.put(pq, trans);

                if (finalStates.contains(p) && other.finalStates.contains(q)) {
                    newFinalStates.add(pq);
                }
            }
        }

        return new DFA(newStates, alphabet, newTransitions, pair(startState, other.startState), newFinalStates);
    }

    private static String pair(String p, String q) {
        return "(" + p + "," + q + ")";
    }
}
