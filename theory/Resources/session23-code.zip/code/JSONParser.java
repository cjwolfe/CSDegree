import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

/**
 * A simple JSON parser for reading automaton definitions.
 * Supports objects, arrays, strings, and basic values.
 */
public class JSONParser {

    private String json;
    private int pos;

    public JSONParser(String json) {
        this.json = json.trim();
        this.pos = 0;
    }

    public JSONObject parseObject() {
        skipWhitespace();
        if (json.charAt(pos) != '{') {
            throw new RuntimeException("Expected '{' at position " + pos);
        }
        pos++; // skip '{'
        
        Map<String, Object> map = new HashMap<>();
        skipWhitespace();
        
        if (json.charAt(pos) == '}') {
            pos++;
            return new JSONObject(map);
        }
        
        while (true) {
            skipWhitespace();
            String key = parseString();
            skipWhitespace();
            
            if (json.charAt(pos) != ':') {
                throw new RuntimeException("Expected ':' at position " + pos);
            }
            pos++; // skip ':'
            
            skipWhitespace();
            Object value = parseValue();
            map.put(key, value);
            
            skipWhitespace();
            if (json.charAt(pos) == '}') {
                pos++;
                break;
            }
            if (json.charAt(pos) == ',') {
                pos++;
            } else {
                throw new RuntimeException("Expected ',' or '}' at position " + pos);
            }
        }
        
        return new JSONObject(map);
    }

    private Object parseValue() {
        skipWhitespace();
        char c = json.charAt(pos);
        
        if (c == '"') {
            return parseString();
        } else if (c == '{') {
            return parseObject();
        } else if (c == '[') {
            return parseArray();
        } else if (c == 't' || c == 'f') {
            return parseBoolean();
        } else if (c == 'n') {
            return parseNull();
        } else if (c == '-' || Character.isDigit(c)) {
            return parseNumber();
        } else {
            throw new RuntimeException("Unexpected character '" + c + "' at position " + pos);
        }
    }

    private String parseString() {
        if (json.charAt(pos) != '"') {
            throw new RuntimeException("Expected '\"' at position " + pos);
        }
        pos++; // skip opening quote
        
        StringBuilder sb = new StringBuilder();
        while (pos < json.length() && json.charAt(pos) != '"') {
            char c = json.charAt(pos);
            if (c == '\\') {
                pos++;
                if (pos >= json.length()) {
                    throw new RuntimeException("Unexpected end of string");
                }
                char escaped = json.charAt(pos);
                switch (escaped) {
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'b': sb.append('\b'); break;
                    case 'f': sb.append('\f'); break;
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    default: throw new RuntimeException("Invalid escape sequence: \\" + escaped);
                }
            } else {
                sb.append(c);
            }
            pos++;
        }
        
        if (pos >= json.length()) {
            throw new RuntimeException("Unterminated string");
        }
        pos++; // skip closing quote
        return sb.toString();
    }

    private JSONArray parseArray() {
        if (json.charAt(pos) != '[') {
            throw new RuntimeException("Expected '[' at position " + pos);
        }
        pos++; // skip '['
        
        List<Object> list = new ArrayList<>();
        skipWhitespace();
        
        if (json.charAt(pos) == ']') {
            pos++;
            return new JSONArray(list);
        }
        
        while (true) {
            skipWhitespace();
            Object value = parseValue();
            list.add(value);
            
            skipWhitespace();
            if (json.charAt(pos) == ']') {
                pos++;
                break;
            }
            if (json.charAt(pos) == ',') {
                pos++;
            } else {
                throw new RuntimeException("Expected ',' or ']' at position " + pos);
            }
        }
        
        return new JSONArray(list);
    }

    private Boolean parseBoolean() {
        if (json.startsWith("true", pos)) {
            pos += 4;
            return true;
        } else if (json.startsWith("false", pos)) {
            pos += 5;
            return false;
        } else {
            throw new RuntimeException("Invalid boolean at position " + pos);
        }
    }

    private Object parseNull() {
        if (json.startsWith("null", pos)) {
            pos += 4;
            return null;
        } else {
            throw new RuntimeException("Invalid null at position " + pos);
        }
    }

    private Number parseNumber() {
        int start = pos;
        if (json.charAt(pos) == '-') {
            pos++;
        }
        while (pos < json.length() && (Character.isDigit(json.charAt(pos)) || json.charAt(pos) == '.')) {
            pos++;
        }
        String numStr = json.substring(start, pos);
        if (numStr.contains(".")) {
            return Double.parseDouble(numStr);
        } else {
            return Integer.parseInt(numStr);
        }
    }

    private void skipWhitespace() {
        while (pos < json.length() && Character.isWhitespace(json.charAt(pos))) {
            pos++;
        }
    }

    /**
     * Represents a JSON object.
     */
    public static class JSONObject {
        private Map<String, Object> map;

        public JSONObject(Map<String, Object> map) {
            this.map = map;
        }

        public String getString(String key) {
            Object value = map.get(key);
            if (value == null) {
                throw new RuntimeException("Key not found: " + key);
            }
            return (String) value;
        }

        public JSONArray getJSONArray(String key) {
            Object value = map.get(key);
            if (value == null) {
                throw new RuntimeException("Key not found: " + key);
            }
            return (JSONArray) value;
        }

        public JSONObject getJSONObject(String key) {
            Object value = map.get(key);
            if (value == null) {
                throw new RuntimeException("Key not found: " + key);
            }
            return (JSONObject) value;
        }

        public boolean has(String key) {
            return map.containsKey(key);
        }

        public Iterable<String> keySet() {
            return map.keySet();
        }
    }

    /**
     * Represents a JSON array.
     */
    public static class JSONArray {
        private List<Object> list;

        public JSONArray(List<Object> list) {
            this.list = list;
        }

        public int length() {
            return list.size();
        }

        public String getString(int index) {
            return (String) list.get(index);
        }

        public JSONObject getJSONObject(int index) {
            return (JSONObject) list.get(index);
        }

        public JSONArray getJSONArray(int index) {
            return (JSONArray) list.get(index);
        }
    }
}
