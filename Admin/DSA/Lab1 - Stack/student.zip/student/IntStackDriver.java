package student;

import java.util.Map;

public class IntStackDriver {

    private static int getMass(char c1){

        return switch (c1) {
            case 'H' -> 1;
            case 'C' -> 12;
            case 'O' -> 16;
            default -> 0;
        };


    }

    public static int calculate(String m)
    {
        char[] f = m.toCharArray();
        double[] massStack = new double[f.length];
        int[] parenStack = new int[f.length];
        int mPtr = 0; // mass stack pointer
        int pPtr = 0; // parenthesis stack pointer

        for (int i = 0; i < f.length; i++) {
            char c = f[i];

            if (c == '(') {
                parenStack[pPtr++] = mPtr;
            } else if (Character.isUpperCase(c)) {
                // char next = (i + 1 < f.length) ? f[i + 1] : '\0';
                double mass = getMass(c);
                // if (Character.isLowerCase(next)) i++; // Skip lowercase char
                
                // Check for multiplier: H2
                int multiplier = 0;
                while (i + 1 < f.length && Character.isDigit(f[i + 1])) {
                    multiplier = multiplier * 10 + (f[++i] - '0');
                }
                massStack[mPtr++] = mass * (multiplier == 0 ? 1 : multiplier);
                
            } else if (c == ')') {
                int start = parenStack[--pPtr];
                double subTotal = 0;
                while (mPtr > start) {
                    subTotal += massStack[--mPtr];
                }

                // Check for multiplier: (OH)2
                int multiplier = 0;
                while (i + 1 < f.length && Character.isDigit(f[i + 1])) {
                    multiplier = multiplier * 10 + (f[++i] - '0');
                }
                massStack[mPtr++] = subTotal * (multiplier == 0 ? 1 : multiplier);
            }
        }

        int total = 0;
        while (mPtr > 0) {
            total += massStack[--mPtr];
        }
        return total;

    }

    public static void main(String[] args){
        IntStack s = new IntStack();
        String input = "";
        String ans = "";

        input = "H2O";

        ans = "18";

        for(int i = 0; i < 3; i++){
            if(i == 1){
                input = "CH(CO2H)3";
                ans = "148";
            }
            if(i == 2){
                input = "((CH)2(OH2H)(C(H))O)3";
                ans = "222";
            }
            System.out.println("Input is " + input);

            System.out.println("Expected molecular mass is " + ans);

            System.out.println("Actual mass is " + calculate(input));


            
        }


        


    }
}
