package student;

public class MolecularMass
{ 
    
    


    public static void main(String[] args)
    {
        java.util.Scanner kb = new java.util.Scanner(System.in);
        System.out.print("Enter the molecule: ");
        String molString = kb.nextLine();     
        System.out.print("Your Molecular Weight is: " + calculate(molString));
    }

    public static int calculate(String m)
    {
        char[] n = m.toCharArray();
        double[] massStack = new double[n.length];
        int[] parenStack = new int[n.length];
        int mPtr = 0; // mass stack pointer
        int pPtr = 0; // parenthesis stack pointer

        for (int i = 0; i < n.length; i++) {
            char c = n[i];

            if (c == '(') {
                parenStack[pPtr++] = mPtr;
            } else if (Character.isUpperCase(c)) {
                // char next = (i + 1 < f.length) ? f[i + 1] : '\0';
                double mass = getMass(c);
                // if (Character.isLowerCase(next)) i++; // Skip lowercase char
                
                // Check for multiplier: H2
                int multiplier = 0;
                while (i + 1 < n.length && Character.isDigit(n[i + 1])) {
                    multiplier = multiplier * 10 + (n[++i] - '0');
                }
                massStack[mPtr++] = mass * (multiplier == 0 ? 1 : multiplier);
                
            } else if (c == ')') {
                int start = parenStack[--pPtr];
                double subTotal = 0;
                while (mPtr > start) {
                    subTotal += massStack[--mPtr];
                }

                // Check for multiplier: (OH)2
                int multiplier = 0;
                while (i + 1 < n.length && Character.isDigit(n[i + 1])) {
                    multiplier = multiplier * 10 + (n[++i] - '0');
                }
                massStack[mPtr++] = subTotal * (multiplier == 0 ? 1 : multiplier);
            }
        }

        int total = 0;
        while (mPtr > 0) {
            total += massStack[--mPtr];
        }
        return total;

    }

    private static int getMass(char c1){

        return switch (c1) {
            case 'H' -> 1;
            case 'C' -> 12;
            case 'O' -> 16;
            default -> 0;
        };


    }
}
