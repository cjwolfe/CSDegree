package remote;

/**
 *A simple espresso machine class
 *
 *@author cwolfe
 *@version 2026 04 28
 */
public class Espresso extends Action{
	private Espresso machine;
	private int shotCount;
	private int temp;
	private int maxTemp;

	private boolean isOn;

	public Espresso(){
		super("Make Espresso");
		this.machine = machine;
		this.shotCount = 0;
		this.temp = 22;
		this.maxTemp = 100;
		this.isOn = false;
		// heatUp(93);

	}

	@Override
	public boolean performAction(){
		if(!isOn){
			power();
		}

		if(temp < 90){
			heatUp(93);
		}

		return pullShot();
		
	}
	
	public void power(){
		isOn = !isOn;
		System.out.printf("Espresso machine is now %s\n", isOn ? "ON" : "OFF");

	}

	public void heatUp(int desiredTemp){
		// if(isOn){power();}
		System.out.println("Espresso machine is heating up!");
		while(temp < desiredTemp && isOn){
			System.out.println("Temp: " + temp + "C");
			temp = Math.min(temp + 15, maxTemp);
			// simulate waiting for it to heat up
			try{
				Thread.sleep(1000);
			} catch (InterruptedException e){
				e.printStackTrace();
			}
		}
		System.out.println("Temperature reached: " + temp + "C");
	}
		
	public boolean pullShot(){
		if(temp < 90){
			// system is not on
			heatUp(93);
		}
		shotCount++;
		System.out.println("Pulling a shot of delicious espresso\n" + shotCount + " Shots today");
		return true;
	}	
}
